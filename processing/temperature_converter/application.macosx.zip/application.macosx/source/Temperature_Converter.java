import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Temperature_Converter extends PApplet {

public void setup() {
  size(500, 800);
  background(255);
}

public void draw() {
  background(255);
  tempFill();
  thermometer();
  strokeWeight(5);
  fill(250, 0, 0);
  ellipse(width/2, 650, 200, 200);
  fill(0);
  textSize(10);
  text("Farenheit Value = " + PApplet.parseInt(height/4-mouseY+300), 20, 200);
  text("Celcius Value = " + farConvert(height/4-mouseY+300), 350, 200);
}

public void tempFill() {
  strokeWeight(5);
  fill(255, 0, 0);
  if (mouseY >= 50 && mouseY < 600) {
    rect(176, 600, 148, mouseY-600);
  } else if (mouseY < 50) {
    rect(176, 50, 148, 600);
  }
}

public void thermometer() {
  noFill();
  rect(175, 50, 150, 600, 5);
  strokeWeight(2);
  for (int i=50; i<600; i+=75) {
    line(177, i, 325, i);
    fill(0);
    text(-i+500, 150, i+5);
  }
}

public float farConvert (float value) {
  value = (value-32) * (5.0f/9.0f);
  return value;
}

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Temperature_Converter" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
